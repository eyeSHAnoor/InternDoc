import React from 'react';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
    Filler,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
    Filler
);

interface ChartCardProps {
    title: string;
    timeframe: string;
    data: number[];
    labels: string[];
    currency?: string;
}

const LineChartCard: React.FC<ChartCardProps> = ({ title, timeframe, data, labels, currency = '' }) => {
    // Create completely different dataset for second line
    const generateSecondDataset = (baseData: number[]) => {
        return baseData.map((value, index) => {
            // Create a completely different pattern:
            // 1. Different base value
            // 2. Different fluctuation pattern
            // 3. Different peaks and valleys
            const base = value * 0.65; // 65% of first line
            const fluctuation = Math.sin(index * 0.8) * (value * 0.3); // Different sine pattern
            const randomFactor = Math.random() * 20 - 10; // Small random variation

            return Math.max(0, base + fluctuation + randomFactor);
        });
    };

    const secondData = generateSecondDataset(data);

    // Create third dataset for even more variation
    const thirdData = data.map((value, index) => {
        // Different pattern - quadratic growth with plateau
        const base = value * 0.5;
        const quadratic = (index * index * 2) - (index * 10);
        const plateau = index > labels.length / 2 ? value * 0.1 : 0;

        return Math.max(0, base + quadratic + plateau + (Math.random() * 15));
    });

    const chartData = {
        labels: labels,
        datasets: [
            {
                label: 'Revenue',
                data: data,
                borderColor: 'rgba(34, 197, 94, 1)', // Green - main line
                backgroundColor: 'rgba(34, 197, 94, 0.1)',
                borderWidth: 3,
                tension: 0.3,
                fill: false,
                pointRadius: 0,
                pointHoverRadius: 6,
                pointBackgroundColor: 'rgba(34, 197, 94, 1)',
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                cubicInterpolationMode: 'monotone' as const,
            },
            {
                label: 'Profit',
                data: thirdData,
                borderColor: 'rgba(59, 130, 246, 1)', // Blue - profit line
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                tension: 0.5,
                fill: {
                    target: 'origin',
                    above: 'rgba(59, 130, 246, 0.05)', // Light blue fill above
                },
                pointRadius: 4,
                pointHoverRadius: 7,
                pointBackgroundColor: 'rgba(59, 130, 246, 1)',
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                pointStyle: 'triangle' as const,
                cubicInterpolationMode: 'monotone' as const,
            }
        ],
    };

    const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false,
                position: 'bottom' as const,
                labels: {
                    boxWidth: 12,
                    padding: 15,
                    usePointStyle: true,
                    pointStyle: 'circle',
                }
            },
            tooltip: {
                mode: 'index' as const,
                intersect: false,
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                titleColor: '#374151',
                bodyColor: '#374151',
                borderColor: '#e5e7eb',
                borderWidth: 2,
                padding: 12,
                boxPadding: 4,
                usePointStyle: true,
                callbacks: {
                    label: (context: any) => {
                        const datasetLabel = context.dataset.label || '';
                        const value = context.parsed.y;
                        return `${datasetLabel}: ${currency}${value.toLocaleString()}`;
                    },
                },
            },
        },
        interaction: {
            intersect: false,
            mode: 'nearest' as const,
        },
        scales: {
            x: {
                grid: {
                    display: true,
                    color: 'rgba(0, 0, 0, 0.05)',
                },
                ticks: {
                    color: '#6b7280',
                    font: {
                        size: 11,
                    },
                },
            },
            y: {
                beginAtZero: true,
                grid: {
                    display: true,
                    color: 'rgba(0, 0, 0, 0.05)',
                },
                ticks: {
                    color: '#6b7280',
                    font: {
                        size: 11,
                    },
                    callback: function (value: any) {
                        return currency + value.toLocaleString();
                    },
                    stepSize: 10,
                },
            },
        },
        elements: {
            line: {
                tension: 0.3,
            },
        },
    };

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
                    <p className="text-xs font-medium">
                        +25% compared to last 30 days
                    </p>
                </div>
                <span className="text-sm text-gray-500 font-medium">{timeframe}</span>
            </div>
            <div className="h-64 relative">
                <Line
                    data={chartData}
                    options={options}
                    plugins={[{
                        id: 'customGridLine',
                        beforeDraw: (chart) => {
                            const ctx = chart.ctx;
                            const yAxis = chart.scales.y;
                            const xAxis = chart.scales.x;

                            // Draw horizontal background bands
                            const yTicks = yAxis.ticks;
                            ctx.save();

                            for (let i = 0; i < yTicks.length - 1; i++) {
                                if (i % 2 === 0) {
                                    const yStart = yAxis.getPixelForTick(i);
                                    const yEnd = yAxis.getPixelForTick(i + 1);

                                    ctx.fillStyle = 'rgba(249, 250, 251, 0.5)';
                                    ctx.fillRect(
                                        xAxis.left,
                                        yStart,
                                        xAxis.right - xAxis.left,
                                        yEnd - yStart
                                    );
                                }
                            }
                            ctx.restore();
                        }
                    }]}
                />
            </div>
            {/* Custom Legend */}
            <div className="flex items-center gap-6 mt-4">
                <div className="flex items-center gap-2">
                    <span className="w-5 h-2 rounded-full bg-green-500"></span>
                    <span className="text-sm ">Revenue</span>
                </div>

                <div className="flex items-center gap-2">
                    <span className="w-5 h-2 rounded-full bg-blue-500"></span>
                    <span className="text-sm ">Profit</span>
                </div>
            </div>



        </div>
    );
};

export default LineChartCard;