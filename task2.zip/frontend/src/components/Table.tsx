// components/Table.tsx
import React, { useState } from 'react';

export interface TableColumn {
    key: string;
    label: string;
    render?: (value: any, row: any) => React.ReactNode;
    className?: string;
}

export interface TableProps {
    data: any[];
    columns: TableColumn[];
    title: string;
    searchPlaceholder?: string;
    addButtonText?: string;
    onAddClick?: () => void;
    onSearch?: (query: string) => void;
    emptyStateMessage?: string;
    dropdownActions?: {
        label: string;
        onClick: (row: any) => void;
        icon?: React.ReactNode;
        className?: string;
    }[];
}

const Table: React.FC<TableProps> = ({
    data,
    columns,
    title,
    searchPlaceholder = "Search...",
    addButtonText = "+ Add New",
    onAddClick,
    onSearch,
    emptyStateMessage = "No data found.",
    dropdownActions = [],
}) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [openDropdownId, setOpenDropdownId] = useState<string | null>(null);

    const toggleDropdown = (id: string) => {
        setOpenDropdownId(openDropdownId === id ? null : id);
    };

    React.useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (openDropdownId && !(event.target as Element).closest('.dropdown-container')) {
                setOpenDropdownId(null);
            }
        };

        document.addEventListener('click', handleClickOutside);
        return () => {
            document.removeEventListener('click', handleClickOutside);
        };
    }, [openDropdownId]);

    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setSearchQuery(value);
        if (onSearch) {
            onSearch(value);
        }
    };

    return (
        <div className="max-w-7xl mx-auto mt-8 p-4">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold text-gray-800">{title}</h1>
                {onAddClick && (
                    <button
                        onClick={onAddClick}
                        className="bg-green-500 hover:bg-green-600 text-white text-sm px-4 py-2 rounded-lg transition-colors duration-200 font-medium"
                    >
                        {addButtonText}
                    </button>
                )}
            </div>

            {/* Search Bar */}

            <div className="px-2 bg-white rounded-xl shadow-sm overflow-hidden border border-gray-200">
                <div className="my-4 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg
                            className="h-5 w-5 text-gray-400"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                            />
                        </svg>
                    </div>
                    <input
                        type="text"
                        placeholder={searchPlaceholder}
                        className="w-full md:w-1/3 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        value={searchQuery}
                        onChange={handleSearch}
                    />
                </div>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                {columns.map((column) => (
                                    <th
                                        key={column.key}
                                        className={`px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${column.className || ''}`}
                                    >
                                        {column.label}
                                    </th>
                                ))}
                                {dropdownActions.length > 0 && (
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Actions
                                    </th>
                                )}
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {data.map((row, index) => (
                                <tr key={row.id || index} className="hover:bg-gray-50 transition-colors duration-150">
                                    {columns.map((column) => (
                                        <td key={`${row.id || index}-${column.key}`} className="px-6 py-4">
                                            {column.render ? column.render(row[column.key], row) : row[column.key]}
                                        </td>
                                    ))}
                                    {dropdownActions.length > 0 && (
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium relative dropdown-container">
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    toggleDropdown(row.id || index.toString());
                                                }}
                                                className="p-2 rounded-lg hover:bg-gray-100 transition-colors duration-200"
                                            >
                                                <svg
                                                    className="w-5 h-5 text-gray-500"
                                                    fill="none"
                                                    stroke="currentColor"
                                                    viewBox="0 0 24 24"
                                                >
                                                    <path
                                                        strokeLinecap="round"
                                                        strokeLinejoin="round"
                                                        strokeWidth={2}
                                                        d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"
                                                    />
                                                </svg>
                                            </button>
                                            {openDropdownId === (row.id || index.toString()) && (
                                                <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-10 overflow-hidden">
                                                    {dropdownActions.map((action, actionIndex) => (
                                                        <button
                                                            key={actionIndex}
                                                            onClick={() => action.onClick(row)}
                                                            className={`w-full text-left px-4 py-3 text-sm hover:bg-gray-50 flex items-center gap-2 ${action.className || 'text-gray-700'}`}
                                                        >
                                                            {action.icon}
                                                            {action.label}
                                                        </button>
                                                    ))}
                                                </div>
                                            )}
                                        </td>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {data.length === 0 && (
                        <div className="text-center py-8 text-gray-500">
                            <svg className="w-12 h-12 mx-auto text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <p className="mt-2">{emptyStateMessage}</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Table;