// ProductsPage.tsx
import React, { useState } from "react";

interface Product {
    id: number;
    title: string;
    link: string;
    image: string;
    status: "Removed" | "Reminder Sent";
}

const products: Product[] = [
    { id: 1, title: "Product A", link: "https://yourproducturlgoeshere1122.com", image: "/product.jpg", status: "Removed" },
    { id: 2, title: "Product B", link: "https://yourproducturlgoeshere1122.com", image: "/product.jpg", status: "Removed" },
    { id: 3, title: "Product C", link: "https://yourproducturlgoeshere1122.com", image: "/product.jpg", status: "Reminder Sent" },
    { id: 4, title: "Product D", link: "https://yourproducturlgoeshere1122.com", image: "/product.jpg", status: "Removed" },
    { id: 5, title: "Product E", link: "https://yourproducturlgoeshere1122.com", image: "/product.jpg", status: "Removed" },
    { id: 6, title: "Product F", link: "https://yourproducturlgoeshere1122.com", image: "/product.jpg", status: "Removed" },
];

const StatusBadge: React.FC<{ status: Product["status"] }> = ({ status }) => {
    const color = status === "Removed" ? "bg-red-100 text-red-500" : "bg-yellow-100 text-yellow-500";
    return <span className={`px-2 py-1 rounded text-xs font-semibold ${color}`}>{status}</span>;
};

const ProductCard: React.FC<{ product: Product }> = ({ product }) => (
    <div className="border rounded-lg p-4 flex flex-col justify-between shadow-sm">
        <img src={product.image} alt={product.title} className="w-full h-40 object-cover rounded" />
        <div className="mt-3">
            <h3 className="font-semibold">{product.title}</h3>
            <a href={product.link} className="text-sm text-gray-400 truncate block">{product.link}</a>
            <div className="mt-2">
                <StatusBadge status={product.status} />
            </div>
            <div className="flex gap-2 mt-3">
                <button className="bg-black text-white px-3 py-1 rounded">Source</button>
                <button className="bg-green-100 text-green-600 px-3 py-1 rounded">View Details</button>
            </div>
        </div>
    </div>
);

const ProductListItem: React.FC<{ product: Product }> = ({ product }) => (
    <div className="flex items-center justify-between border-b py-3">
        <div className="flex items-center gap-4">
            <img src={product.image} alt={product.title} className="w-16 h-16 object-cover rounded" />
            <div>
                <h3 className="font-semibold">{product.title}</h3>
                <a href={product.link} className="text-sm text-gray-400 truncate block">{product.link}</a>
            </div>
            <StatusBadge status={product.status} />
        </div>
        <div className="flex items-center gap-4">
            <button className="bg-black text-white px-3 py-3 text-sm rounded">Source</button>
            <button className="bg-green-100 text-green-600 px-3 py-3 text-sm rounded">View Details</button>
        </div>
    </div>
);

const Products: React.FC = () => {
    const [view, setView] = useState<"grid" | "list">("list");

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">Products</h2>
                <div className="flex gap-2">
                    <button
                        className={`px-3 py-1 rounded ${view === "grid" ? "bg-black text-white" : "bg-gray-100"}`}
                        onClick={() => setView("grid")}
                    >
                        Grid View
                    </button>
                    <button
                        className={`px-3 py-1 rounded ${view === "list" ? "bg-black text-white" : "bg-gray-100"}`}
                        onClick={() => setView("list")}
                    >
                        List View
                    </button>
                </div>
            </div>
            {view === "grid" ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {products.map((product) => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            ) : (
                <div className="flex flex-col">
                    {products.map((product) => (
                        <ProductListItem key={product.id} product={product} />
                    ))}
                </div>
            )}
        </div>
    );
};

export default Products;
